from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

def get_response(user_message):
    msg = user_message.lower().strip()

    # Greetings
    if any(word in msg for word in ["hello", "hi", "hey", "greetings", "good morning", "good evening", "good afternoon"]):
        return ("👋 Welcome to the University Admission Assistant! I'm here to help you with all your admission-related queries. "
                "You can ask me about:<br><br>"
                "📋 <b>Admission Process</b><br>"
                "📅 <b>Deadlines</b><br>"
                "📚 <b>Programs & Degrees</b><br>"
                "💰 <b>Fee Structure</b><br>"
                "🎓 <b>Scholarships</b><br>"
                "🏠 <b>Hostel Facilities</b><br>"
                "📞 <b>Contact Information</b><br><br>"
                "How can I assist you today?")

    # Admission process
    if any(word in msg for word in ["admission", "apply", "application", "how to apply", "enroll", "enrollment"]):
        return ("📋 <b>Admission Process</b><br><br>"
                "Here's how to apply to our university:<br><br>"
                "1️⃣ <b>Online Registration</b> – Visit our official portal and create an account.<br>"
                "2️⃣ <b>Fill Application Form</b> – Complete the online application with your academic details.<br>"
                "3️⃣ <b>Upload Documents</b> – Submit transcripts, ID, photo, and required certificates.<br>"
                "4️⃣ <b>Pay Application Fee</b> – Pay the non-refundable application fee of <b>PKR 1,500</b>.<br>"
                "5️⃣ <b>Appear for Entry Test</b> – Sit for the university entrance exam.<br>"
                "6️⃣ <b>Merit List</b> – Check the merit list published within 2 weeks of the test.<br>"
                "7️⃣ <b>Confirm Admission</b> – Pay the semester fee to confirm your seat.<br><br>"
                "🌐 Apply online at: <b>https://www.superior.edu.pk/admissions</b>")

    # Deadlines
    if any(word in msg for word in ["deadline", "last date", "date", "when", "schedule", "timeline"]):
        return ("📅 <b>Admission Deadlines 2025</b><br><br>"
                "🍂 <b>Fall Semester (Sep 2025)</b><br>"
                "&nbsp;&nbsp;• Application Opens: <b>June 1, 2025</b><br>"
                "&nbsp;&nbsp;• Last Date to Apply: <b>July 31, 2025</b><br>"
                "&nbsp;&nbsp;• Entry Test: <b>August 10, 2025</b><br>"
                "&nbsp;&nbsp;• Merit List: <b>August 25, 2025</b><br>"
                "&nbsp;&nbsp;• Fee Submission: <b>September 5, 2025</b><br><br>"
                "🌸 <b>Spring Semester (Feb 2026)</b><br>"
                "&nbsp;&nbsp;• Application Opens: <b>November 1, 2025</b><br>"
                "&nbsp;&nbsp;• Last Date to Apply: <b>December 20, 2025</b><br>"
                "&nbsp;&nbsp;• Entry Test: <b>January 10, 2026</b><br><br>"
                "⚠️ <i>Late applications are not accepted under any circumstances.</i>")

    # Requirements / eligibility
    if any(word in msg for word in ["requirement", "eligibility", "criteria", "qualify", "qualification", "entry", "needed", "documents"]):
        return ("📚 <b>Entry Requirements</b><br><br>"
                "🎓 <b>Undergraduate Programs:</b><br>"
                "&nbsp;&nbsp;• Intermediate / A-Levels (minimum <b>50% marks</b>)<br>"
                "&nbsp;&nbsp;• Pass university entry test<br>"
                "&nbsp;&nbsp;• CNIC / B-Form copy<br>"
                "&nbsp;&nbsp;• Domicile Certificate<br>"
                "&nbsp;&nbsp;• 4 passport-size photographs<br><br>"
                "🎓 <b>Postgraduate Programs:</b><br>"
                "&nbsp;&nbsp;• Bachelor's degree (minimum <b>2nd Division</b>)<br>"
                "&nbsp;&nbsp;• GAT/NTS score (where applicable)<br>"
                "&nbsp;&nbsp;• 2 reference letters<br>"
                "&nbsp;&nbsp;• Statement of Purpose<br><br>"
                "🎓 <b>PhD Programs:</b><br>"
                "&nbsp;&nbsp;• Master's degree with <b>3.0+ CGPA</b><br>"
                "&nbsp;&nbsp;• Research proposal<br>"
                "&nbsp;&nbsp;• Interview with faculty committee")

    # Programs / degrees
    if any(word in msg for word in ["program", "degree", "course", "major", "department", "faculty", "bs", "ms", "phd", "bachelor", "master"]):
        return ("🎓 <b>Available Programs</b><br><br>"
                "💻 <b>Faculty of Computing & IT</b><br>"
                "&nbsp;&nbsp;• BS Computer Science (4 years)<br>"
                "&nbsp;&nbsp;• BS Software Engineering (4 years)<br>"
                "&nbsp;&nbsp;• BS Artificial Intelligence (4 years)<br>"
                "&nbsp;&nbsp;• MS Computer Science (2 years)<br>"
                "&nbsp;&nbsp;• PhD Computer Science<br><br>"
                "📊 <b>Faculty of Business</b><br>"
                "&nbsp;&nbsp;• BBA – Business Administration (4 years)<br>"
                "&nbsp;&nbsp;• BS Accounting & Finance (4 years)<br>"
                "&nbsp;&nbsp;• MBA (1.5 / 2 years)<br><br>"
                "⚗️ <b>Faculty of Sciences</b><br>"
                "&nbsp;&nbsp;• BS Mathematics<br>"
                "&nbsp;&nbsp;• BS Physics<br>"
                "&nbsp;&nbsp;• BS Chemistry<br><br>"
                "🏛️ <b>Faculty of Social Sciences</b><br>"
                "&nbsp;&nbsp;• BS Psychology<br>"
                "&nbsp;&nbsp;• BS Economics<br>"
                "&nbsp;&nbsp;• BS Media Studies<br><br>"
                "📖 <b>Faculty of Engineering</b><br>"
                "&nbsp;&nbsp;• BE Electrical Engineering<br>"
                "&nbsp;&nbsp;• BE Civil Engineering<br>"
                "&nbsp;&nbsp;• BE Mechanical Engineering")

    # Fee structure
    if any(word in msg for word in ["fee", "cost", "tuition", "charges", "price", "payment", "pay", "money", "expense"]):
        return ("💰 <b>Fee Structure (Per Semester)</b><br><br>"
                "🎓 <b>Undergraduate Programs</b><br>"
                "&nbsp;&nbsp;• BS Computer Science: <b>PKR 65,000</b><br>"
                "&nbsp;&nbsp;• BS Software Engineering: <b>PKR 65,000</b><br>"
                "&nbsp;&nbsp;• BBA / Business: <b>PKR 55,000</b><br>"
                "&nbsp;&nbsp;• BS Sciences: <b>PKR 45,000</b><br>"
                "&nbsp;&nbsp;• BE Engineering: <b>PKR 80,000</b><br><br>"
                "🎓 <b>Postgraduate Programs</b><br>"
                "&nbsp;&nbsp;• MS Programs: <b>PKR 90,000</b><br>"
                "&nbsp;&nbsp;• MBA: <b>PKR 95,000</b><br>"
                "&nbsp;&nbsp;• PhD Programs: <b>PKR 1,10,000</b><br><br>"
                "📋 <b>Additional Charges</b><br>"
                "&nbsp;&nbsp;• Registration Fee (one-time): <b>PKR 5,000</b><br>"
                "&nbsp;&nbsp;• Library Fee: <b>PKR 2,000/semester</b><br>"
                "&nbsp;&nbsp;• Lab Fee (if applicable): <b>PKR 3,000/semester</b><br><br>"
                "💳 Payment accepted via bank transfer, JazzCash, or EasyPaisa.")

    # Scholarships
    if any(word in msg for word in ["scholarship", "financial aid", "bursary", "grant", "funding", "stipend", "award", "merit"]):
        return ("🏆 <b>Scholarship Programs</b><br><br>"
                "⭐ <b>Merit Scholarships</b><br>"
                "&nbsp;&nbsp;• 90%+ marks in intermediate → <b>100% fee waiver</b><br>"
                "&nbsp;&nbsp;• 80–89% marks → <b>50% fee waiver</b><br>"
                "&nbsp;&nbsp;• 70–79% marks → <b>25% fee waiver</b><br><br>"
                "🌍 <b>Need-Based Scholarships</b><br>"
                "&nbsp;&nbsp;• For students from low-income families<br>"
                "&nbsp;&nbsp;• Covers up to <b>75% of tuition fee</b><br>"
                "&nbsp;&nbsp;• Requires income certificate & family declaration<br><br>"
                "🏛️ <b>Government Scholarships</b><br>"
                "&nbsp;&nbsp;• HEC Need-Based Scholarships<br>"
                "&nbsp;&nbsp;• Prime Minister's Laptop Scheme<br>"
                "&nbsp;&nbsp;• PEEF Scholarships (Punjab students)<br><br>"
                "🔬 <b>Research Scholarships (PhD)</b><br>"
                "&nbsp;&nbsp;• Full tuition + monthly stipend of <b>PKR 40,000</b><br><br>"
                "📩 Apply for scholarships at: <b>scholarships@university.edu.pk</b>")

    # Hostel
    if any(word in msg for word in ["hostel", "accommodation", "housing", "dorm", "dormitory", "room", "stay", "residence"]):
        return ("🏠 <b>Hostel & Accommodation</b><br><br>"
                "Our university provides separate, fully secure hostels for male and female students.<br><br>"
                "🛏️ <b>Room Types</b><br>"
                "&nbsp;&nbsp;• Single Room: <b>PKR 8,000/month</b><br>"
                "&nbsp;&nbsp;• Double Sharing: <b>PKR 5,500/month</b><br>"
                "&nbsp;&nbsp;• Triple Sharing: <b>PKR 4,000/month</b><br><br>"
                "✅ <b>Facilities Included</b><br>"
                "&nbsp;&nbsp;• 24/7 Security & CCTV Surveillance<br>"
                "&nbsp;&nbsp;• Free Wi-Fi (50 Mbps)<br>"
                "&nbsp;&nbsp;• Dining Hall & Cafeteria<br>"
                "&nbsp;&nbsp;• Laundry Services<br>"
                "&nbsp;&nbsp;• Common Room & Study Hall<br>"
                "&nbsp;&nbsp;• Generator Backup<br><br>"
                "📩 Apply for hostel accommodation via the student portal after admission confirmation.<br>"
                "Seats are limited – <b>first come, first served.</b>")

    # Contact
    if any(word in msg for word in ["contact", "phone", "email", "address", "location", "reach", "call", "office", "helpline"]):
        return ("📞 <b>Contact Information</b><br><br>"
                "🏫 <b>University Name:</b> Excellence University<br>"
                "📍 <b>Address:</b> Main University Road, Lahore, Punjab, Pakistan<br><br>"
                "📞 <b>Phone Numbers:</b><br>"
                "&nbsp;&nbsp;• Admissions Office: <b>042-35880001</b><br>"
                "&nbsp;&nbsp;• General Inquiry: <b>042-35880002</b><br>"
                "&nbsp;&nbsp;• WhatsApp Helpline: <b>0300-1234567</b><br><br>"
                "📧 <b>Email Addresses:</b><br>"
                "&nbsp;&nbsp;• Admissions: admissions@university.edu.pk<br>"
                "&nbsp;&nbsp;• Scholarships: scholarships@university.edu.pk<br>"
                "&nbsp;&nbsp;• General: info@university.edu.pk<br><br>"
                "🕐 <b>Office Hours:</b> Monday–Friday, 9:00 AM – 5:00 PM<br>"
                "🌐 <b>Website:</b> https://www.superior.edu.pk/ ")

    # Thank you
    if any(word in msg for word in ["thank", "thanks", "thankyou", "thnx", "appreciate"]):
        return ("😊 You're very welcome! I'm always here to help you navigate your academic journey. "
                "Feel free to ask me anything else about admissions, programs, fees, or any other queries. "
                "Good luck with your application! 🎓✨")

    # Bye
    if any(word in msg for word in ["bye", "goodbye", "see you", "later", "exit", "quit"]):
        return ("👋 Goodbye! Thank you for using the University Admission Assistant. "
                "Best of luck with your admissions journey! Don't hesitate to return if you have more questions. 🎓")

    # Fallback
    return ("🤔 Sorry, I didn't quite understand your question. I'm best at helping with:<br><br>"
            "• 📋 <b>Admission Process</b> – type 'admission'<br>"
            "• 📅 <b>Deadlines</b> – type 'deadline'<br>"
            "• 📚 <b>Programs</b> – type 'programs'<br>"
            "• ✅ <b>Requirements</b> – type 'requirements'<br>"
            "• 💰 <b>Fees</b> – type 'fee'<br>"
            "• 🏆 <b>Scholarships</b> – type 'scholarship'<br>"
            "• 🏠 <b>Hostel</b> – type 'hostel'<br>"
            "• 📞 <b>Contact</b> – type 'contact'<br><br>"
            "Please rephrase your question or use one of the keywords above!")


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/get", methods=["POST"])
def chat():
    user_message = request.json.get("message", "")
    if not user_message.strip():
        return jsonify({"response": "Please type a message first! 😊"})
    response = get_response(user_message)
    return jsonify({"response": response})


if __name__ == "__main__":
    app.run(debug=True)



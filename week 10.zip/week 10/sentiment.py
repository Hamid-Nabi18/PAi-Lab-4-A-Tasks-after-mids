
from textblob import TextBlob

def main():
    sentence = input("Enter a sentence to analyze its sentiment: ").strip()
    if not sentence:
        print("Error: You entered an empty sentence. Please try again.")
        return
    blob = TextBlob(sentence)
    polarity = blob.sentiment.polarity
    subjectivity = blob.sentiment.subjectivity
    if polarity > 0.1:
        sentiment = "Positive"
    elif polarity < -0.1:
        sentiment = "Negative"
    else:
        sentiment = "Neutral"
    print("\n--- Sentiment Analysis Results ---")
    print(f"Sentence: {sentence}")
    print(f"Polarity Score: {polarity:.2f} (ranges from -1.0 to 1.0)")
    print(f"Subjectivity Score: {subjectivity:.2f} (ranges from 0.0 to 1.0)")
    print(f"Overall Sentiment: {sentiment}")
if __name__ == "__main__":
    main()